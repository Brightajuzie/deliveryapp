<?php

return [
    'reference' => [
        'reference_type' => '',
    ],
    'reference_amount' => [
        'reference_amount' => '',
        'max_earning_per_month' => '',
    ],
];
