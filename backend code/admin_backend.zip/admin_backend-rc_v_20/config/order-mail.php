<?php
return [
    'order_mail' => [
        'order_active_mail' => '',
        'order_cancel_mail' => '',
        'order_completed_mail' => '',
        'order_courier_arrived_mail' => '',
        'order_courier_assigned_mail' => '',
        'order_courier_departed_mail' => '',
        'order_courier_pickup_up_mail' => '',
        'order_create_mail' => '',
        'order_return_mail' => '',
        'order_shipped_mail' => '',
        'order_reschedule_mail' => '',
        'register_mail' => '',
    ],
];
