<?php

return [
    'insurance' => [
        'insurance_allow' => '',
    ],
    'insurance_percentage' => [
        'insurance_percentage' => '',
    ],
    'insurance_description' => [
        'insurance_description' => '',
    ],
    'claim_duration' => [
        'claim_duration' => '',
    ]
];
