<?php

return [
    'ORDER' => [

        'distance' => '',
        // 'auto_assign' => '',
    ],
];

