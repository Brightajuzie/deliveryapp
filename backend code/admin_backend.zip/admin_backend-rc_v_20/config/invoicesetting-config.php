<?php

return [
    'INVOICE' => [
        'company_name' => '',
        'company_contact_number' => '',
        'company_address' => '',
    ],
];
