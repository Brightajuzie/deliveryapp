<?php

return [
    'register_setting' => [
        'mobile_verification' => '',
        'document_verification' => '',
        'email_verification' => '',
        'allow_deliveryman' => '',
    ],
];
